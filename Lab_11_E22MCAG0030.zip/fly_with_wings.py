# E22MCAG0030
# Abhishek Yadav
from fly_behavior import FlyBehavior

class FlyWithWings(FlyBehavior):
    def fly(self):
        print("Flying with wings")
