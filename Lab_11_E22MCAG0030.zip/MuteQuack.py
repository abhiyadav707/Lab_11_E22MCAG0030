# E22MCAG0030
# Abhishek Yadav
from QuackBehavior import QuackBehavior


class MuteQuack(QuackBehavior):
    def quack(self):
        print("No sound")