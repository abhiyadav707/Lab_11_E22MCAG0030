# E22MCAG0030
# Abhishek Yadav
from fly_behavior import FlyBehavior

class FlyNoWay(FlyBehavior):
    def fly(self):
        print("It cannot fly,Unable to fly")

