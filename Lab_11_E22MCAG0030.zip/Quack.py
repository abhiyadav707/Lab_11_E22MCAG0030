# E22MCAG0030
# Abhishek Yadav
from QuackBehavior import QuackBehavior


class Quack(QuackBehavior):
    def quack(self):
        print("Quacking")
