# E22MCAG0030
# Abhishek Yadav
from QuackBehavior import QuackBehavior


class Squeak(QuackBehavior):
    def quack(self):
        print("Squeaked")
